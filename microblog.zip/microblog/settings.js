module.exports = {
	cookie_secret : 'secret_meteoric',
	db : 'microblog',
	host : 'localhost',
	port : 27017
}